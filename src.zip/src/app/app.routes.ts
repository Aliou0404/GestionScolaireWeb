import { Routes } from '@angular/router';
import {DetailsApprenantComponent} from './details-apprenant/details-apprenant.component';
import {AccueilComponent} from './accueil/accueil.component';

export const routes: Routes = [
  {path: '', redirectTo: '/accueil', pathMatch: 'full'},
  //{path: '', component: DetailsApprenantComponent},
  {path: 'details-apprenant',component: DetailsApprenantComponent},
  {path: 'accueil', component: AccueilComponent},
];
