import { Component } from '@angular/core';

@Component({
  selector: 'app-pied-page',
  imports: [],
  templateUrl: './pied-page.component.html',
  styleUrl: './pied-page.component.scss'
})
export class PiedPageComponent {

}
