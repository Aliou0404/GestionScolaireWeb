export interface Apprenant{
  id ?: number,
  nom: string,
  prenom:string,
  image: string;


}

export interface Enseignant{
  id ?: number,
  nom: string,
  prenom: string;

}









