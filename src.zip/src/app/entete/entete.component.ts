import { Component } from '@angular/core';

@Component({
  selector: 'app-entete',
  imports: [],
  templateUrl: './entete.component.html',
  styleUrl: './entete.component.scss'
})
export class EnteteComponent {

}
